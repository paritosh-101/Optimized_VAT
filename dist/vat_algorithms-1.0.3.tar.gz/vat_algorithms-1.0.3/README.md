VAT algorithms implemented.
